package edu.acaiza.adapter;

/**
 *
 * @author USUARIO
 */
public class DemoAdapter {

    public static void main(String[] args) {

        AudioPlayer audioPlayer = new AudioPlayer();
        audioPlayer.play("mp3", "Despacito");
        audioPlayer.play("mp4", "50 sombras de Grey");
           audioPlayer.play("vlc", "nacho");
            audioPlayer.play("avi", "Trololo.avi");
        // System.out.println(audioPlayer);}
     
       

    }
}
