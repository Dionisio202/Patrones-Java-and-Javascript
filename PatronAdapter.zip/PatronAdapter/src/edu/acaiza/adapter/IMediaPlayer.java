/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.acaiza.adapter;

/**
 *
 * @author USUARIO
 */
public interface IMediaPlayer {
    
    
    public void play (String typeAudio , String fileName);    
    }
    

